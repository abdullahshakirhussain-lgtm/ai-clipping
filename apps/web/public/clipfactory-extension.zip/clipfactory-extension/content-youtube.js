"use strict";
(() => {
  // src/protocol.ts
  function buildCaption(job) {
    return [job.title, job.description, job.hashtags.join(" ")].filter(Boolean).join("\n\n");
  }

  // src/content-youtube.ts
  function send(msg) {
    chrome.runtime.sendMessage(msg).catch(() => {
    });
  }
  function status(jobId, message) {
    send({ type: "status", jobId, message });
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function waitFor(find, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    for (; ; ) {
      const el = find();
      if (el) return el;
      if (Date.now() > deadline) return null;
      await sleep(400);
    }
  }
  var q = (sel) => document.querySelector(sel);
  function click(el) {
    if (!el) return false;
    el.click();
    return true;
  }
  function titleBox() {
    return q("#title-textarea #textbox, ytcp-social-suggestions-textbox#title-textarea #textbox");
  }
  function descBox() {
    return q("#description-textarea #textbox, ytcp-social-suggestions-textbox#description-textarea #textbox");
  }
  function setEditable(el, text) {
    el.focus();
    const sel = window.getSelection();
    if (sel) {
      sel.selectAllChildren(el);
      const ok = document.execCommand("insertText", false, text);
      if (ok) return;
    }
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
  }
  var URL_RE = /https?:\/\/(?:youtu\.be\/[\w-]+|(?:www\.)?youtube\.com\/(?:watch\?v=|shorts\/)[\w-]+)/;
  function findPublishedUrl() {
    for (const a of Array.from(document.querySelectorAll("a[href*='youtu']"))) {
      const m = URL_RE.exec(a.href) ?? URL_RE.exec(a.textContent ?? "");
      if (m) return m[0];
    }
    for (const input of Array.from(document.querySelectorAll("input[value*='youtu']"))) {
      const m = URL_RE.exec(input.value);
      if (m) return m[0];
    }
    return null;
  }
  async function watchForPublish(jobId) {
    const found = await waitFor(findPublishedUrl, 30 * 60 * 1e3);
    if (found) send({ type: "result", jobId, url: found });
    else send({ type: "result", jobId, error: "timed out waiting for the published URL" });
  }
  var VISIBILITY_PUBLIC = 'tp-yt-paper-radio-button[name="PUBLIC"]';
  function onVisibilityStep() {
    return !!q(VISIBILITY_PUBLIC);
  }
  async function autoPublish(jobId) {
    const notForKids = await waitFor(
      () => q('tp-yt-paper-radio-button[name="VIDEO_MADE_FOR_KIDS_NOT_MFK"]'),
      2e4
    );
    if (notForKids) click(notForKids);
    await sleep(400);
    for (let i = 0; i < 5 && !onVisibilityStep(); i++) {
      if (!click(q("#next-button"))) break;
      await sleep(1200);
    }
    if (!onVisibilityStep()) throw new Error("couldn't reach the visibility step");
    status(jobId, "Setting visibility to Public\u2026");
    click(await waitFor(() => q(VISIBILITY_PUBLIC), 15e3));
    await sleep(600);
    const done = await waitFor(() => {
      const b = q("#done-button");
      if (!b) return null;
      return b.getAttribute("aria-disabled") === "true" ? null : b;
    }, 30 * 60 * 1e3);
    if (!done) throw new Error("publish button never enabled");
    click(done);
    status(jobId, "Publishing\u2026");
  }
  function activeChannelName() {
    const el = q("#account-name, ytcp-account-section #account-name, #entity-name");
    const name = el?.textContent?.trim();
    return name && name.length > 0 ? name : null;
  }
  async function run(job) {
    const chan = activeChannelName();
    if (chan) status(job.jobId, `Uploading as: ${chan}`);
    status(job.jobId, "Waiting for the upload dialog\u2026");
    const title = await waitFor(titleBox, 5 * 60 * 1e3);
    if (!title) {
      send({ type: "result", jobId: job.jobId, error: "upload dialog didn't appear (did you pick the file?)" });
      return;
    }
    const caption = buildCaption(job);
    setEditable(title, job.title.slice(0, 100));
    await sleep(300);
    const desc = descBox();
    if (desc) setEditable(desc, caption);
    status(job.jobId, "Filled title + description. Automating the rest\u2026");
    void watchForPublish(job.jobId);
    try {
      await autoPublish(job.jobId);
    } catch (err) {
      status(job.jobId, `Couldn't auto-finish (${err instanceof Error ? err.message : String(err)}). Finish in YouTube \u2014 I'll still grab the link.`);
    }
  }
  chrome.runtime.sendMessage({ type: "getJob" }).then((job) => {
    if (job) void run(job);
  }).catch(() => {
  });
})();
