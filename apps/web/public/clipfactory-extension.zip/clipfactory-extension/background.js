"use strict";
(() => {
  // src/background.ts
  var key = (tabId) => `job_${tabId}`;
  function uploadUrl(job) {
    switch (job.platform) {
      case "YOUTUBE":
        return job.channelId ? `https://studio.youtube.com/channel/${encodeURIComponent(job.channelId)}/videos/upload?d=ud` : "https://www.youtube.com/upload";
      case "TIKTOK":
        return "https://www.tiktok.com/tiktokstudio/upload";
      case "FACEBOOK":
        return "https://business.facebook.com/latest/composer";
      default:
        return null;
    }
  }
  async function startPost(job, dashTabId) {
    const url = uploadUrl(job);
    if (!url) {
      relay(dashTabId, { type: "result", jobId: job.jobId, error: `${job.platform} posting isn't wired up yet` });
      return;
    }
    try {
      await chrome.downloads.download({ url: job.downloadUrl, filename: job.filename });
    } catch (err) {
      relay(dashTabId, { type: "result", jobId: job.jobId, error: `download failed: ${String(err)}` });
      return;
    }
    const tab = await chrome.tabs.create({ url });
    if (tab.id == null) {
      relay(dashTabId, { type: "result", jobId: job.jobId, error: "could not open upload tab" });
      return;
    }
    await chrome.storage.session.set({ [key(tab.id)]: { job, dashTabId } });
    const where = job.platform === "TIKTOK" ? "TikTok" : job.platform === "FACEBOOK" ? "Facebook" : "YouTube";
    relay(dashTabId, { type: "status", jobId: job.jobId, message: `Opened ${where} \u2014 pick the downloaded clip to start.` });
  }
  function relay(dashTabId, msg) {
    if (msg.type === "status") void chrome.storage.session.set({ lastStatus: msg.message });
    else if (msg.type === "result") {
      void chrome.storage.session.set({ lastStatus: msg.error ? `Error: ${msg.error}` : `Posted: ${msg.url}` });
    }
    chrome.tabs.sendMessage(dashTabId, msg).catch(() => {
    });
  }
  chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    const msg = raw;
    if (msg.type === "postJob") {
      const dashTabId = sender.tab?.id;
      if (dashTabId == null) return;
      void startPost(msg.job, dashTabId);
      return;
    }
    if (msg.type === "getJob") {
      const tabId = sender.tab?.id;
      if (tabId == null) {
        sendResponse(null);
        return true;
      }
      void chrome.storage.session.get(key(tabId)).then((store) => {
        sendResponse(store[key(tabId)]?.job ?? null);
      });
      return true;
    }
    if (msg.type === "status" || msg.type === "result") {
      const tabId = sender.tab?.id;
      if (tabId == null) return;
      void chrome.storage.session.get(key(tabId)).then((store) => {
        const stored = store[key(tabId)];
        if (!stored) return;
        relay(stored.dashTabId, msg);
        if (msg.type === "result") void chrome.storage.session.remove(key(tabId));
      });
      return;
    }
  });
})();
