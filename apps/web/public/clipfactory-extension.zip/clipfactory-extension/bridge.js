"use strict";
(() => {
  // src/protocol.ts
  var PAGE_SOURCE = "clipfactory-dashboard";
  var EXT_SOURCE = "clipfactory-ext";

  // src/bridge.ts
  function toPage(msg) {
    window.postMessage(msg, window.location.origin);
  }
  toPage({ source: EXT_SOURCE, kind: "hello" });
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (!data || data.source !== PAGE_SOURCE) return;
    if (data.kind === "ping") {
      toPage({ source: EXT_SOURCE, kind: "pong" });
      return;
    }
    if (data.kind === "postJob") {
      const msg = { type: "postJob", job: data.job };
      chrome.runtime.sendMessage(msg).catch((err) => {
        toPage({ source: EXT_SOURCE, kind: "result", jobId: data.job.jobId, error: String(err) });
      });
    }
  });
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "status") {
      toPage({ source: EXT_SOURCE, kind: "status", jobId: msg.jobId, message: msg.message });
    } else if (msg.type === "result") {
      toPage({ source: EXT_SOURCE, kind: "result", jobId: msg.jobId, url: msg.url, error: msg.error });
    }
  });
})();
