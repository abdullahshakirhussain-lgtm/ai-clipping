"use strict";
(() => {
  // src/protocol.ts
  function buildCaption(job) {
    return [job.title, job.description, job.hashtags.join(" ")].filter(Boolean).join("\n\n");
  }

  // src/content-facebook.ts
  function send(msg) {
    chrome.runtime.sendMessage(msg).catch(() => {
    });
  }
  function status(jobId, message) {
    send({ type: "status", jobId, message });
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function waitFor(find, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    for (; ; ) {
      const el = find();
      if (el) return el;
      if (Date.now() > deadline) return null;
      await sleep(500);
    }
  }
  function composerBox() {
    return document.querySelector(
      'div[role="textbox"][contenteditable="true"], div[contenteditable="true"][aria-label*="post" i], div[contenteditable="true"][aria-label*="mind" i]'
    );
  }
  function setEditable(el, text) {
    el.focus();
    const sel = window.getSelection();
    if (sel) {
      sel.selectAllChildren(el);
      if (document.execCommand("insertText", false, text)) return;
    }
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
  }
  function publishButton() {
    const byAria = document.querySelector(
      'div[aria-label="Publish"][role="button"], button[aria-label="Publish"]'
    );
    if (byAria && byAria.getAttribute("aria-disabled") !== "true") return byAria;
    for (const b of Array.from(document.querySelectorAll('div[role="button"], button'))) {
      if (b.textContent?.trim() === "Publish" && b.getAttribute("aria-disabled") !== "true") return b;
    }
    return null;
  }
  var URL_RE = /https?:\/\/(?:www\.|business\.)?facebook\.com\/[\w.-]+\/(?:posts|videos|reel)\/[\w-]+/;
  function findPostedUrl() {
    for (const a of Array.from(document.querySelectorAll("a[href*='facebook.com/']"))) {
      const m = URL_RE.exec(a.href);
      if (m) return m[0];
    }
    return null;
  }
  async function run(job) {
    status(job.jobId, "Waiting for the Facebook composer\u2026");
    const box = await waitFor(composerBox, 5 * 60 * 1e3);
    if (!box) {
      send({ type: "result", jobId: job.jobId, error: "composer didn't appear (open a post composer and pick the file?)" });
      return;
    }
    setEditable(box, buildCaption(job));
    status(job.jobId, "Caption filled. Confirm the Page, then publishing\u2026");
    const publish = await waitFor(publishButton, 30 * 60 * 1e3);
    if (publish) {
      publish.click();
      status(job.jobId, "Publishing\u2026");
    } else {
      status(job.jobId, "Couldn't find Publish \u2014 post manually; I'll grab the link if it appears.");
    }
    const url = await waitFor(findPostedUrl, 10 * 60 * 1e3);
    if (url) send({ type: "result", jobId: job.jobId, url });
    else send({ type: "result", jobId: job.jobId, error: "posted, but couldn't capture the URL \u2014 paste it to mark done" });
  }
  chrome.runtime.sendMessage({ type: "getJob" }).then((job) => {
    if (job) void run(job);
  }).catch(() => {
  });
})();
