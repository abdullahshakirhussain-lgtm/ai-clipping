"use strict";
(() => {
  // src/popup.ts
  chrome.storage.session.get("lastStatus").then((s) => {
    const last = s.lastStatus;
    const el = document.getElementById("last");
    if (el && last) el.textContent = last;
  });
})();
