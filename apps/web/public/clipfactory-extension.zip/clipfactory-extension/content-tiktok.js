"use strict";
(() => {
  // src/protocol.ts
  function buildCaption(job) {
    return [job.title, job.description, job.hashtags.join(" ")].filter(Boolean).join("\n\n");
  }

  // src/content-tiktok.ts
  function send(msg) {
    chrome.runtime.sendMessage(msg).catch(() => {
    });
  }
  function status(jobId, message) {
    send({ type: "status", jobId, message });
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function waitFor(find, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    for (; ; ) {
      const el = find();
      if (el) return el;
      if (Date.now() > deadline) return null;
      await sleep(400);
    }
  }
  function captionBox() {
    return document.querySelector(
      '.public-DraftEditor-content[contenteditable="true"], div[data-contents="true"] [contenteditable="true"], div[contenteditable="true"][role="textbox"]'
    );
  }
  function setEditable(el, text) {
    el.focus();
    const sel = window.getSelection();
    if (sel) {
      sel.selectAllChildren(el);
      if (document.execCommand("insertText", false, text)) return;
    }
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true }));
  }
  function postButton() {
    const byE2e = document.querySelector('button[data-e2e="post_video_button"]');
    if (byE2e) return byE2e;
    for (const b of Array.from(document.querySelectorAll("button"))) {
      if (b.textContent?.trim().toLowerCase() === "post" && !b.disabled) return b;
    }
    return null;
  }
  var URL_RE = /https?:\/\/(?:www\.)?tiktok\.com\/@[\w.-]+\/video\/\d+/;
  function findPostedUrl() {
    for (const a of Array.from(document.querySelectorAll("a[href*='/video/']"))) {
      const m2 = URL_RE.exec(a.href);
      if (m2) return m2[0];
    }
    const m = URL_RE.exec(location.href);
    return m ? m[0] : null;
  }
  async function run(job) {
    status(job.jobId, "Waiting for TikTok's editor\u2026");
    const box = await waitFor(captionBox, 5 * 60 * 1e3);
    if (!box) {
      send({ type: "result", jobId: job.jobId, error: "caption editor didn't appear (did you pick the file?)" });
      return;
    }
    setEditable(box, buildCaption(job));
    status(job.jobId, "Caption filled. Posting when TikTok finishes processing\u2026");
    const post = await waitFor(postButton, 30 * 60 * 1e3);
    if (post) {
      post.click();
      status(job.jobId, "Posting\u2026");
    } else {
      status(job.jobId, "Couldn't find the Post button \u2014 post manually; I'll grab the link if it appears.");
    }
    const url = await waitFor(findPostedUrl, 10 * 60 * 1e3);
    if (url) send({ type: "result", jobId: job.jobId, url });
    else send({ type: "result", jobId: job.jobId, error: "posted, but couldn't capture the URL \u2014 paste it to mark done" });
  }
  chrome.runtime.sendMessage({ type: "getJob" }).then((job) => {
    if (job) void run(job);
  }).catch(() => {
  });
})();
